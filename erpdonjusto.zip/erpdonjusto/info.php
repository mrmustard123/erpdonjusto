<?php
	phpinfo();

?>