<?php

/*
File: connection
Author: Leonardo G. Tellez Saucedo
Created on: 21 ene. de 2025 21:22:01
Email: leonardo616@gmail.com
*/

function connect_db(){
    


            /* the connection configuration*/
            $dbParams = array(
                'driver'   => 'pdo_mysql',
                'user'     => 'apicolado20_usr',
                'password' => 'P4p4n03l123',
                'dbname'   => 'apicolado20_erpdonjusto',


            );
            
            return $dbParams;

    
}


