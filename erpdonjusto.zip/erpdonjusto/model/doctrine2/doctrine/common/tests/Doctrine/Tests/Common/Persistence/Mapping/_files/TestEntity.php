<?php

$metadata->getFieldNames();